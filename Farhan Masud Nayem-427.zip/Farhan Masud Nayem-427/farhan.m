clc;
clear all;
close all;

img = imread('Hydrangeas.jpg');
gray = rgb2gray(img);

F_edge = edge(gray, 'prewitt');

s = strel('disk', 2); 
dilated_img = imdilate(F_edge, s);

figure;

subplot(2,2,1);
imshow(img);
title('Original Image');

subplot(2,2,2);
imshow(gray);
title('Grayscale Image');

subplot(2,2,3);
imshow(F_edge);
title('Detected Edge');

subplot(2,2,4);
imshow(dilated_img);
title('Dilated Image');
